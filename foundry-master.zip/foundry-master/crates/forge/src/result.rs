//! Test outcomes.

use alloy_primitives::{Address, Log};
use foundry_common::evm::Breakpoints;
use foundry_evm::{
    coverage::HitMaps,
    debug::DebugArena,
    executors::EvmError,
    fuzz::{CounterExample, FuzzCase},
    traces::{TraceKind, Traces},
};
use serde::{Deserialize, Serialize};
use std::{
    collections::{BTreeMap, HashMap},
    fmt::{self, Write},
    time::Duration,
};
use yansi::Paint;

/// Results and duration for a set of tests included in the same test contract
#[derive(Clone, Debug, Serialize)]
pub struct SuiteResult {
    /// Total duration of the test run for this block of tests
    pub duration: Duration,
    /// Individual test results. `test fn signature -> TestResult`
    pub test_results: BTreeMap<String, TestResult>,
    /// Warnings
    pub warnings: Vec<String>,
}

impl SuiteResult {
    pub fn new(
        duration: Duration,
        test_results: BTreeMap<String, TestResult>,
        warnings: Vec<String>,
    ) -> Self {
        Self { duration, test_results, warnings }
    }

    /// Iterator over all succeeding tests and their names
    pub fn successes(&self) -> impl Iterator<Item = (&String, &TestResult)> {
        self.tests().filter(|(_, t)| t.status == TestStatus::Success)
    }

    /// Iterator over all failing tests and their names
    pub fn failures(&self) -> impl Iterator<Item = (&String, &TestResult)> {
        self.tests().filter(|(_, t)| t.status == TestStatus::Failure)
    }

    /// Iterator over all tests and their names
    pub fn tests(&self) -> impl Iterator<Item = (&String, &TestResult)> {
        self.test_results.iter()
    }

    /// Whether this test suite is empty.
    pub fn is_empty(&self) -> bool {
        self.test_results.is_empty()
    }

    /// The number of tests in this test suite.
    pub fn len(&self) -> usize {
        self.test_results.len()
    }
}

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
pub enum TestStatus {
    Success,
    #[default]
    Failure,
    Skipped,
}

impl TestStatus {
    /// Returns `true` if the test was successful.
    #[inline]
    pub fn is_success(self) -> bool {
        matches!(self, Self::Success)
    }

    /// Returns `true` if the test failed.
    #[inline]
    pub fn is_failure(self) -> bool {
        matches!(self, Self::Failure)
    }

    /// Returns `true` if the test was skipped.
    #[inline]
    pub fn is_skipped(self) -> bool {
        matches!(self, Self::Skipped)
    }
}

/// The result of an executed solidity test
#[derive(Clone, Debug, Default, Serialize, Deserialize)]
pub struct TestResult {
    /// The test status, indicating whether the test case succeeded, failed, or was marked as
    /// skipped. This means that the transaction executed properly, the test was marked as
    /// skipped with vm.skip(), or that there was a revert and that the test was expected to
    /// fail (prefixed with `testFail`)
    pub status: TestStatus,

    /// If there was a revert, this field will be populated. Note that the test can
    /// still be successful (i.e self.success == true) when it's expected to fail.
    pub reason: Option<String>,

    /// Minimal reproduction test case for failing test
    pub counterexample: Option<CounterExample>,

    /// Any captured & parsed as strings logs along the test's execution which should
    /// be printed to the user.
    pub logs: Vec<Log>,

    /// The decoded DSTest logging events and Hardhat's `console.log` from [logs](Self::logs).
    pub decoded_logs: Vec<String>,

    /// What kind of test this was
    pub kind: TestKind,

    /// Traces
    #[serde(skip)]
    pub traces: Traces,

    /// Raw coverage info
    #[serde(skip)]
    pub coverage: Option<HitMaps>,

    /// Labeled addresses
    pub labeled_addresses: HashMap<Address, String>,

    /// The debug nodes of the call
    pub debug: Option<DebugArena>,

    /// pc breakpoint char map
    pub breakpoints: Breakpoints,
}

impl fmt::Display for TestResult {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self.status {
            TestStatus::Success => Paint::green("[PASS]").fmt(f),
            TestStatus::Skipped => Paint::yellow("[SKIP]").fmt(f),
            TestStatus::Failure => {
                let mut s = String::from("[FAIL. Reason: ");

                let reason = self.reason.as_deref().unwrap_or("assertion failed");
                s.push_str(reason);

                if let Some(counterexample) = &self.counterexample {
                    match counterexample {
                        CounterExample::Single(ex) => {
                            write!(s, "; counterexample: {ex}]").unwrap();
                        }
                        CounterExample::Sequence(sequence) => {
                            s.push_str("]\n\t[Sequence]\n");
                            for ex in sequence {
                                writeln!(s, "\t\t{ex}").unwrap();
                            }
                        }
                    }
                } else {
                    s.push(']');
                }

                Paint::red(s).fmt(f)
            }
        }
    }
}

impl TestResult {
    pub fn fail(reason: String) -> Self {
        Self { status: TestStatus::Failure, reason: Some(reason), ..Default::default() }
    }

    /// Returns `true` if this is the result of a fuzz test
    pub fn is_fuzz(&self) -> bool {
        matches!(self.kind, TestKind::Fuzz { .. })
    }
}

/// Data report by a test.
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum TestKindReport {
    Standard { gas: u64 },
    Fuzz { runs: usize, mean_gas: u64, median_gas: u64 },
    Invariant { runs: usize, calls: usize, reverts: usize },
}

impl fmt::Display for TestKindReport {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            TestKindReport::Standard { gas } => {
                write!(f, "(gas: {gas})")
            }
            TestKindReport::Fuzz { runs, mean_gas, median_gas } => {
                write!(f, "(runs: {runs}, μ: {mean_gas}, ~: {median_gas})")
            }
            TestKindReport::Invariant { runs, calls, reverts } => {
                write!(f, "(runs: {runs}, calls: {calls}, reverts: {reverts})")
            }
        }
    }
}

impl TestKindReport {
    /// Returns the main gas value to compare against
    pub fn gas(&self) -> u64 {
        match self {
            TestKindReport::Standard { gas } => *gas,
            // We use the median for comparisons
            TestKindReport::Fuzz { median_gas, .. } => *median_gas,
            // We return 0 since it's not applicable
            TestKindReport::Invariant { .. } => 0,
        }
    }
}

/// Various types of tests
#[derive(Clone, Debug, Serialize, Deserialize)]
pub enum TestKind {
    /// A standard test that consists of calling the defined solidity function
    ///
    /// Holds the consumed gas
    Standard(u64),
    /// A solidity fuzz test, that stores all test cases
    Fuzz {
        /// we keep this for the debugger
        first_case: FuzzCase,
        runs: usize,
        mean_gas: u64,
        median_gas: u64,
    },
    /// A solidity invariant test, that stores all test cases
    Invariant { runs: usize, calls: usize, reverts: usize },
}

impl Default for TestKind {
    fn default() -> Self {
        Self::Standard(0)
    }
}

impl TestKind {
    /// The gas consumed by this test
    pub fn report(&self) -> TestKindReport {
        match self {
            TestKind::Standard(gas) => TestKindReport::Standard { gas: *gas },
            TestKind::Fuzz { runs, mean_gas, median_gas, .. } => {
                TestKindReport::Fuzz { runs: *runs, mean_gas: *mean_gas, median_gas: *median_gas }
            }
            TestKind::Invariant { runs, calls, reverts } => {
                TestKindReport::Invariant { runs: *runs, calls: *calls, reverts: *reverts }
            }
        }
    }
}

#[derive(Clone, Debug, Default)]
pub struct TestSetup {
    /// The address at which the test contract was deployed
    pub address: Address,
    /// The logs emitted during setup
    pub logs: Vec<Log>,
    /// Call traces of the setup
    pub traces: Traces,
    /// Addresses labeled during setup
    pub labeled_addresses: HashMap<Address, String>,
    /// The reason the setup failed, if it did
    pub reason: Option<String>,
    /// Coverage info during setup
    pub coverage: Option<HitMaps>,
}

impl TestSetup {
    pub fn from_evm_error_with(
        error: EvmError,
        mut logs: Vec<Log>,
        mut traces: Traces,
        mut labeled_addresses: HashMap<Address, String>,
    ) -> Self {
        match error {
            EvmError::Execution(err) => {
                // force the tracekind to be setup so a trace is shown.
                traces.extend(err.traces.map(|traces| (TraceKind::Setup, traces)));
                logs.extend(err.logs);
                labeled_addresses.extend(err.labels);
                Self::failed_with(logs, traces, labeled_addresses, err.reason)
            }
            e => Self::failed_with(
                logs,
                traces,
                labeled_addresses,
                format!("failed to deploy contract: {e}"),
            ),
        }
    }

    pub fn success(
        address: Address,
        logs: Vec<Log>,
        traces: Traces,
        labeled_addresses: HashMap<Address, String>,
        coverage: Option<HitMaps>,
    ) -> Self {
        Self { address, logs, traces, labeled_addresses, reason: None, coverage }
    }

    pub fn failed_with(
        logs: Vec<Log>,
        traces: Traces,
        labeled_addresses: HashMap<Address, String>,
        reason: String,
    ) -> Self {
        Self {
            address: Address::ZERO,
            logs,
            traces,
            labeled_addresses,
            reason: Some(reason),
            coverage: None,
        }
    }

    pub fn failed(reason: String) -> Self {
        Self { reason: Some(reason), ..Default::default() }
    }
}
